import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Guessing guessing = new Guessing();
        GuessingScore gss = new GuessingScore(guessing);

        System.out.println("Please enter a number to guess:");

        while (true) {
            int guessNum = sc.nextInt();
            guessing.setGuessingNumber(guessNum);
            boolean isCorrect = guessing.guessingGame(guessNum);
            gss.printGuessingScore(isCorrect);
            if (isCorrect) break;
        }
        sc.close();
    }
}
