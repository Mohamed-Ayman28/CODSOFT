public class GuessingScore {
    private int score = 0;
    private Guessing guessing;

    public GuessingScore(Guessing guessing) {
        this.guessing = guessing;
    }

    public void printGuessingScore(boolean isCorrectGuess) {
        if (isCorrectGuess) {
            score++;
        }
        else
        {
            score++;
        }
         System.out.println("Your current score: " + score);
    }
}