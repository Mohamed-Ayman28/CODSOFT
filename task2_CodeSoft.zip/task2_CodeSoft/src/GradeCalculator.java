class GradeCalculator {
    public void CalculateTotalMarkesAndAverage(int num_courses, int[] marks) {
        int total = 0;
        for (int i = 0; i < num_courses; i++) {
            total += marks[i];
        }
        System.out.println("Total marks: " + total);

        double average = (double) total / num_courses;
        System.out.printf("The average is: %.2f%%\n", average);
    }
}
