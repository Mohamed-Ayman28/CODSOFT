import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter the number of courses:");
        int n = input.nextInt();


        Course[] courses = new Course[n];


        for (int i = 0; i < n; i++) {
            input.nextLine();

            System.out.println("Enter course name for course " + (i + 1) + ":");
            String courseName = input.nextLine();

            System.out.println("Enter course code for course " + (i + 1) + ":");
            String courseCode = input.nextLine();

            System.out.println("Enter grade for course " + (i + 1) + ":");
            int courseGrade = input.nextInt();

            courses[i] = new Course(courseName, courseCode);
            courses[i].setCourseGrade(courseGrade);
        }

        GradeCalculator gradeCalculator = new GradeCalculator();
        int[] marks = new int[n];
        for (int i = 0; i < n; i++) {
            marks[i] = courses[i].getCourseGrade();
        }

        gradeCalculator.CalculateTotalMarkesAndAverage(n, marks);


        for (int i = 0; i < n; i++) {
            System.out.println("Course Name: " + courses[i].getCourseName() +
                    ", Course Code: " + courses[i].getCourseCode() +
                    ", Grade: " + courses[i].getCourseGrade());
        }
    }
}