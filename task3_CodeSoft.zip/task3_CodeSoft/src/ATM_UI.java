public interface ATM_UI {
    void start();
}