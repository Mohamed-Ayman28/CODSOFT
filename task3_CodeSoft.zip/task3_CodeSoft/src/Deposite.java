public class Deposite implements ATM_UI {
    private UserBankAccount USaccount;

    @Override
    public void start() {
        System.out.println("waiting for your Deposite");
    }

    public void deposite(int accountNumber, double amount) {
        USaccount = UserBankAccount.getInstance();
        UserBankAccount.User user = USaccount.findUserByAccountNumber(accountNumber);
        if (user != null) {
            user.balance += amount;
            System.out.println("Deposit successful. New balance: $" + user.balance);
        } else {
            System.out.println("Account not found.");
        }
    }
}