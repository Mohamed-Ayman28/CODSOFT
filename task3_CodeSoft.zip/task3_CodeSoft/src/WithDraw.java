public class WithDraw implements ATM_UI {
    private UserBankAccount USaccount;

    @Override
    public void start() {
        System.out.println("waiting for your withdraw");
    }

    public void Withdraw(int userpin, double amount) {
        USaccount = UserBankAccount.getInstance();
        UserBankAccount.User user = USaccount.findUserByAccountNumber(userpin);
        if (user != null) {
            if (amount > user.balance) {
                System.out.println("Not enough money.");
            } else {
                user.balance -= amount;
                System.out.println("Withdrawal successful. New balance: $" + user.balance);
            }
        } else {
            System.out.println("Account not found.");
        }
    }
}