import java.util.Scanner;

public class ATM {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ATM_UI ui = null;

        while (true) {
            System.out.println("1-Deposit");
            System.out.println("2-Withdraw");
            System.out.println("3-Check Balance");
            System.out.println("4-Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    ui = new Deposite();
                    System.out.print("Enter your PIN: ");
                    int UserPin = scanner.nextInt();
                    System.out.print("Enter amount to deposite: ");
                    double depositAmount = scanner.nextDouble();
                    ui.start();
                    ((Deposite) ui).deposite(UserPin, depositAmount);
                    break;
                case 2:
                    ui = new WithDraw();
                    System.out.print("Enter your PIN: ");
                    int withdrawPin = scanner.nextInt();
                    System.out.print("Enter amount to withdraw: ");
                    double withdrawAmount = scanner.nextDouble();
                    ui.start();
                    ((WithDraw) ui).Withdraw(withdrawPin, withdrawAmount);
                    break;
                case 3:
                    ui = new CheckBalance();
                    System.out.print("Enter your PIN: ");
                    int checkBalancePin = scanner.nextInt();
                    ui.start();
                    ((CheckBalance) ui).checkbalance(checkBalancePin);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}