import java.util.ArrayList;

class UserBankAccount {
    private static UserBankAccount instance = null;

    static class User {
        String name;
        int accountNumber;
        double balance;
        int userpin;

        User(String name, int accountNumber, double balance, int userpin) {
            this.name = name;
            this.accountNumber = accountNumber;
            this.balance = balance;
            this.userpin = userpin;
        }

        void displayUserDetails() {
            System.out.println("Name: " + name);
            System.out.println("Account Number: " + accountNumber);
            System.out.println("Balance: $" + balance);
            System.out.println("-----------------------------");
        }
    }

    private ArrayList<User> users;

    private UserBankAccount() {
        users = new ArrayList<>();
        users.add(new User("Mohamed Ayman Fikry", 1001, 1500.50, 4626));
        users.add(new User("Ahmed Sayed Ahmed", 1002, 2500.75, 2596));
        users.add(new User("Mona sami saad", 1003, 3000.00, 2559));
    }

    public static UserBankAccount getInstance() {
        if (instance == null) {
            instance = new UserBankAccount();
        }
        return instance;
    }

    public void displayAllUsers() {
        for (User user : users) {
            user.displayUserDetails();
        }
    }

    public User findUserByAccountNumber(int userpin) {
        for (User user : users) {
            if (user.userpin == userpin) {
                return user;
            }
        }
        return null;
    }

    public double retreiveBalance(int userpin) {
        for (User user : users) {
            if (user.userpin == userpin) {
                return user.balance;
            }
        }
        return 0;
    }
}