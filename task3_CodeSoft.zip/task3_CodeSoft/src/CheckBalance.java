public class CheckBalance implements ATM_UI {
    private UserBankAccount USaccount;

    @Override
    public void start() {
        System.out.println("waiting for your check balance...");
    }

    public void checkbalance(int userpin) {
        USaccount = UserBankAccount.getInstance();
        double balance = USaccount.retreiveBalance(userpin);
        System.out.println("Balance: $" + balance);
    }
}