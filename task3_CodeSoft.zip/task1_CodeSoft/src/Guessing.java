import java.util.Random ;
public class Guessing {
    private final int minNum = 1;
    private final int maxNum = 100;
    private int guessingNumber;
    private int randomNumber;

    // Constructor initializes a new random number
    public Guessing() {
        Random rand = new Random();
        this.randomNumber = rand.nextInt(maxNum - minNum + 1) + minNum;
        System.out.println("Debug: The random number is " + randomNumber);
    }

    public int getGuessingNumber() {
        return guessingNumber;
    }

    public void setGuessingNumber(int guessingNumber) {
        this.guessingNumber = guessingNumber;
    }

    public int getRandomNumber() {
        return randomNumber;
    }

    public boolean guessingGame(int guessNum) {
        if (guessNum < minNum || guessNum > maxNum) {
            System.out.println("Invalid input! Please guess a number between " + minNum + " and " + maxNum);
            return false;
        }
        if (guessNum == randomNumber) {
            System.out.println("Your guessing is correct, congratulations!");
            return true;
        } else if (guessNum > randomNumber) {
            System.out.println("Your guessing is too high, try again.");
        } else {
            System.out.println("Your guessing is too low, try again.");
        }
        return false;
    }
}