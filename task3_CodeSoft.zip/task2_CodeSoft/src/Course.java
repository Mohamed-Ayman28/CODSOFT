class Course {
    private String courseName;
    private int CourseGrade;
    private String courseCode;

    public Course() {}

    public Course(String courseName, String courseCode) {
        this.courseName = courseName;
        this.courseCode = courseCode;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }

    public int getCourseGrade() {
        return CourseGrade;
    }

    public void setCourseGrade(int courseGrade) {
        CourseGrade = courseGrade;
    }
}